﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace Annotation.Models
{
    public class NdaMembers
    {
        public string NdaId { get; set; }

        [DisplayName("Ten dang nhap")]
        [Required(ErrorMessage = "ten dang nhap dang trong")]
        [StringLength(20, MinimumLength = 10, ErrorMessage = "ten tu 10 den 20 ki tu")]
        public string NdaName { get; set; }

        [DisplayName("Mat khau")]
        [Required(ErrorMessage = "mat khau dang trong")]
        [StringLength(16, MinimumLength = 8, ErrorMessage = "mat khau phai tu 8 den 16 ki tu")]
        public string NdaPassword { get; set; }

        [DisplayName("Email")]
        [Required(ErrorMessage = "email dang trong")]
        [EmailAddress(ErrorMessage = "email khong dung dinh dang (vd: abc@gmail.com)")]
        public string NdaEmail { get; set; }

        [DisplayName("So dien thoai")]
        [Required(ErrorMessage = "so dien thoai dang trong")]
        [RegularExpression(@"^\d{11}$", ErrorMessage = "so dien thoai phai co dung 11 chu so")]
        public string NdaPhone { get; set; }
    }
}