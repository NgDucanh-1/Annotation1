﻿using Microsoft.AspNetCore.Mvc;
using Annotation.Models;

namespace Annotation.Controllers
{
    public class NdaMembersController : Controller
    {
       
        public IActionResult Index()
        {
            
            return View();
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(NdaMembers model)
        {
           
            if (ModelState.IsValid)
            {
               
                TempData["SuccessMessage"] = "Đăng ký thành viên thành công!";
                return RedirectToAction(nameof(Index));
            }

          
            return View(model);
        }
    }
}